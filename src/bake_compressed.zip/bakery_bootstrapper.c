#include <stdio.h>

extern char _binary_bakery_start;
extern char _binary_bakery_end;

int main () {
  char * p = &_binary_bakery_start;
  char * e = &_binary_bakery_end;

  while ( p != e ) {
    putchar(*p++);
  }
}