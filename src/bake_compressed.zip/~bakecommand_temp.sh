source /usr/bin/baketools.sh
target="bake"
c_standard="c++17"
compiler="g++"
new_ingredient bake bake.cpp
new_ingredient baketools_cpp baketools/baketools.cpp
define_all bake_version 0.1.2
bake_all
