#include "baketools.hpp"
#include <iostream>
#include <string>

using std::string;

int main ( int argc, char ** argv )
{
  // This program will create a self-contained executable for installation

}